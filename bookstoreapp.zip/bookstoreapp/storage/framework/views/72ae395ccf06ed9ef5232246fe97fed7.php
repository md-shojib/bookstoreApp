<form action="/update" method="POST">
        <?php echo csrf_field(); ?>
        <br></br>
            <input type="text" name="id" value="<?php echo e($book['id']); ?>" placeholder="Enter a isbn">
            <br></br>
            <input type="text" name="isbn" value="<?php echo e($book['isbn']); ?>" placeholder="Enter a title">
            <br></br>
            <input type="text" name="title" value="<?php echo e($book['title']); ?>" placeholder="Enter a title">
            <br></br>
            <input type="text" name="author" value="<?php echo e($book['author']); ?>" placeholder="Enter a author">
            <br></br>
            <input type="text" name="stock" value="<?php echo e($book['stock']); ?>" placeholder="Enter stock">
            <br></br>
            <input type="text" name="price" value="<?php echo e($book['price']); ?>" placeholder="Enter price">
            <br></br>
            <button type="submit" class="btn btn-secondary">Update</button>
        </form><?php /**PATH /home/shojib/Desktop/lab/webeng/bookstoreapp/resources/views/update.blade.php ENDPATH**/ ?>